import Vue from 'vue'
import Vuex from 'vuex'
Vue.use(Vuex)

const store = new Vuex.Store({
	state: {
		orderList: [],
		orderData: {
			count: 0,
			money: 0
		},
		dishesIndex: null
	},
	mutations: {
		CLEAN_DISHES(state, playload) {
			state.orderList = []
			state.orderData = {
				count: 0,
				money: 0
			}
		},
		// 查询订单列表有无 相同口味和菜式 的索引
		GET_DISHESINDEX(state, playload) {
			state.dishesIndex = null;
			for (let index = 0; index < state.orderList.length; index++) {
				if (state.orderList[index].id == playload.id && state.orderList[index].type == playload.type) {
					state.dishesIndex = index;
					break;
				}
			}
		},
		SET_COUNT(state, playload) {
			// 订单列表无该类型索引 则添加到订单列表中
			if (state.dishesIndex == null) {
				state.orderData.count++;
				state.orderData.money += playload.row.price;
				state.orderList.push(playload.row);
				return
			}
			if (playload.type) {
				// 数量 +1
				state.orderList[state.dishesIndex].count++;
				state.orderData.money += state.orderList[state.dishesIndex].price;
			} else {
				// 数量 -1
				state.orderList[state.dishesIndex].count--;
				state.orderData.money -= state.orderList[state.dishesIndex].price;
				// 减至数量为0时，删掉该订单
				if (state.orderList[state.dishesIndex].count == 0) {
					state.orderData.count--;
					state.orderList.splice(state.dishesIndex, 1);
				}
			}
		}
	},
	actions: {
		CHANGE_COUNT({
			commit
		}, playload) {
			commit('GET_DISHESINDEX', playload.row);
			commit('SET_COUNT', playload);
		},
		CLEAN_DISHES({
			commit
		}, playload) {
			uni.showModal({
				title: '确定清空购物车吗？',
				success: function(res) {
					if (res.confirm) {
						commit('CLEAN_DISHES')
					}
				}
			});
		}
	}
})

export default store
