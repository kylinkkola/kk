<template>
	<view class="orderDetail">
		<view class="orderDetail-warn">
			<view>
				<text>请在指定时间内</text>
				<view>前往收银台支付！</view>
			</view>
			<view class="orderDetail-time">
				<text>{{ minute < 10 ? `0${minute}` : minute }}</text>
				<text>:</text>
				<text>{{ second < 10 ? `0${second}` : second }}</text>
			</view>
		</view>
		<view class="orderDetail-page">
			<view class="orderDetail-info">
				<orderItem :dishesData="list"></orderItem>
				<view class="orderDetail-detail">
					<view>
						<text>订单编号：</text>
						<text>5151654646654</text>
					</view>
					<view>
						<text>订单时间：</text>
						<text>2020-04-29</text>
					</view>
					<view>
						<text>商品金额：</text>
						<text>￥{{ orderData.money }}</text>
					</view>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
import orderItem from '../../components/orderItem.vue';
import { mapState } from 'vuex';
export default {
	components: {
		orderItem
	},
	data() {
		return {
			list: [],
			minute: 30,
			second: 0
		};
	},
	computed: {
		...mapState(['orderList', 'orderData'])
	},
	onLoad(option) {
		if (option.id) {
			this.list = [];
		} else {
			this.handleRunTime();
			this.list = this.orderList;
		}
	},
	methods: {
		handleRunTime() {
			let timer = setInterval(() => {
				if (this.second == 0) {
					if (this.minute <= 0) {
						clearInterval(timer);
						return;
					}
					this.minute--;
					this.second = 59;
				} else {
					this.second--;
				}
			}, 1000);
		}
	}
};
</script>

<style lang="scss">
@import './index.scss';
</style>
