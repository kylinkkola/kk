export const orderOperation = [{
		value: "随便点",
		imgUrl: "../../static/ic_01@2x.png"
	},
	{
		value: "热销榜",
		imgUrl: "../../static/ic_02@2x.png"
	},
	{
		value: "点过的菜",
		imgUrl: "../../static/ic_03@2x.png"
	}
]

export const dishesData = [{
	id: 1,
	name: '酱油爆鸡',
	price: 59,
	imgUrl: '../../static/mao.png'
}, {
	id: 2,
	name: '藤椒牛蛙',
	price: 109,
	imgUrl: '../../static/mao.png'
}, {
	id: 3,
	name: '盗版太二酸菜鱼',
	price: 49,
	imgUrl: '../../static/mao.png'
}]

export const typeList = [{
	key: 'size',
	title: '规格',
	data: [{
			id: 1,
			value: '大份'
		},
		{
			id: 2,
			value: '小份'
		}
	]
}, {
	key: 'taste',
	title: '口味',
	data: [{
			id: 1,
			value: '蒜香'
		},
		{
			id: 2,
			value: '孜然'
		},
		{
			id: 3,
			value: '椒盐'
		}
	]
}, {
	key: 'hot',
	title: '辣度',
	data: [{
			id: 1,
			value: '微辣'
		},
		{
			id: 2,
			value: '中辣'
		},
		{
			id: 3,
			value: '大辣'
		}
	]
}]
