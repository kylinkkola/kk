<template>
	<view class="orderDishes">
		<view class="dishes-operation">
			<view v-for="(item, index) in orderOperation" :key="index">
				<image :src="item.imgUrl"></image>
				<view>{{ item.value }}</view>
			</view>
		</view>
		<scroll-view
			class="scroll"
			:style="'height:' + sHeight"
			scroll-y="true"
			:scroll-into-view="goId"
			scroll-with-animation="true"
		>
			<view class="dishes-list" v-for="item in 8" :key="item" :id="'test' + item">
				<view>—— 精选主菜 ——</view>
				<view>
					<view v-for="(item, index) in dishesData" :key="index">
						<image :src="item.imgUrl"></image>
						<text>{{ item.name }}</text>
						<view>
							<text>￥{{ item.price }}</text>
							<image
								@click="handleSelect(item, $event)"
								src="../../static/ic_add@2x.png"
							/>
						</view>
					</view>
				</view>
			</view>
		</scroll-view>
		<view :class="['dishes-info', { 'dishes-info-zIndex': infoVisible }]">
			<view>
				<text>￥</text>
				<text>{{ orderData.money }}</text>
			</view>
			<view @click="handleSubmit">提交订单</view>
			<view @click="handlePopup">
				<text v-if="orderData.count > 0">{{ orderData.count }}</text>
				<image src="../../static/ic_order@2x.png"></image>
			</view>
		</view>
		<popup :isVisible.sync="infoVisible">
			<view class="dishes-detail">
				<view>
					<text>7号桌</text>
					<view>
						<image src="../../static/ic_clear@2x.png"></image>
						<text @click="CLEAN_DISHES">清空购物车</text>
					</view>
				</view>
				<view class="dishes">
					<view v-for="(item, index) in orderList" :key="index">
						<image :src="item.imgUrl"></image>
						<view>
							<text>{{ item.name }}</text>
							<view>{{ item.type }}</view>
							<view>
								<text>￥</text>
								<text>{{ item.price }}</text>
							</view>
						</view>
						<view>
							<text @click="handleDel(item)">-</text>
							<text>{{ item.count }}</text>
							<image
								src="../../static/ic_add@2x.png"
								@click="handleAdd(item)"
							></image>
						</view>
					</view>
				</view>
			</view>
		</popup>
		<popup position="center" width="600rpx" borderRadius="10rpx" :isVisible.sync="typeVisible">
			<view class="orderDishes-type">
				<view v-if="selectDishes">
					<image :src="selectDishes.imgUrl"></image>
					<view>
						<view>{{ selectDishes.name }}</view>
						<view>￥{{ selectDishes.price }}</view>
					</view>
				</view>
				<checkBox
					ref="box"
					v-for="(item, index) in typeList"
					:key="index"
					:data="item.data"
					:value="type[index]"
					:title="item.title"
					name="value"
					id="value"
				></checkBox>
			</view>
			<view class="orderDishes-add" @click="handleAdd(false)">加入购物车</view>
		</popup>
		<drawer @on-click="handleGoId"></drawer>
		<view :class="['pAnimate',pAnimate]" ref="pAnimate">
			<image :class="cAnimate" ref="cAnimate" src="../../static/ic_add@2x.png" />
		</view>
	</view>
</template>

<script>
import popup from '../../components/popup.vue';
import drawer from '../../components/drawer.vue';
import checkBox from '../../components/checkBox.vue';
import { orderOperation, dishesData, typeList } from './index.js';
import { mapState, mapMutations, mapActions } from 'vuex';
export default {
	components: {
		popup,
		drawer,
		checkBox
	},
	data() {
		return {
			goId: null,
			value: null,
			sHeight: null,
			pAnimate: null,
			cAnimate: null,
			selectDishes: null,
			infoVisible: false,
			typeVisible: false,
			type: [],
			typeList: typeList,
			dishesData: dishesData,
			orderOperation: orderOperation
		};
	},
	computed: {
		...mapState(['orderList', 'orderData'])
	},
	mounted() {
		uni.getSystemInfo({
			success: res => {
				const query = uni.createSelectorQuery().in(this);
				query
					.select('.scroll')
					.boundingClientRect(data => {
						console.log(data.top);
						this.sHeight = res.windowHeight - data.top + 'px';
					})
					.exec();
			}
		});
	},
	methods: {
		...mapActions(['CHANGE_COUNT', 'CLEAN_DISHES']),
		handleSubmit() {
			if (this.orderList.length > 0) {
				uni.navigateTo({
					url: '../orderSubmit/index'
				});
			} else {
				uni.showToast({
					icon: 'none',
					title: '至少选一样菜哦！'
				});
			}
			this.pAnimate = null;
			this.cAnimate = null;
		},
		handleSelect(row, event) {
			this.selectDishes = row;
			this.typeVisible = true;
			this.$refs.box.map((item, index) => {
				this.$refs.box[index].value = '';
			});
			this.pAnimate = null;
			this.cAnimate = null;
		},
		handleDel(row) {
			this.CHANGE_COUNT({
				row: row,
				type: false
			});
		},
		handleAdd(row) {
			this.pAnimate = 'orderDishes-pAnimate';
			this.cAnimate = 'orderDishes-cAnimate';

			this.type = this.$refs.box.map((item, index) => {
				return this.$refs.box[index].value;
			});

			setTimeout(() => {
				if (!row) {
					row = {
						count: 1,
						...this.selectDishes,
						type: this.type.filter(Boolean).join('、')
					};
				}

				this.CHANGE_COUNT({
					row: row,
					type: true
				});
			}, 500);
			
			this.typeVisible = false;
		},
		handlePopup() {
			this.infoVisible = !this.infoVisible;
		},
		handleGoId(id) {
			this.goId = id;
			setTimeout(() => {
				this.goId = null;
			});
		}
	}
};
</script>

<style lang="scss">
@import './index.scss';
.dishes-info-zIndex {
	z-index: 1002;
	bottom: 55%;
}
</style>
