<template>
	<view class="myInfo">
		<view class="myInfo-item" v-for="item in 10" :key="item">
			<view>
				<text>好吃的烧烤</text>
				<text style="color: red;">待支付</text>
			</view>
			<view>
				<scroll-view class="scroll" scroll-x="true">
					<image v-for="item in 4" :key="item"></image>
				</scroll-view>
				<view>
					<text>￥248</text>
					<view>共4件</view>
				</view>
			</view>
			<view>
				<text>日期：2020-04-30 18:22:28</text>
				<view @click="handleDetail">查看详情</view>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		methods:{
			handleDetail(){
				uni.navigateTo({
					url:'../orderDetail/index?id=1'
				})
			}
		}
	}
</script>

<style lang="scss">
@import './index.scss';
</style>
