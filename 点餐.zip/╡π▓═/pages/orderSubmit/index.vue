<template>
	<view class="orderSubmit">
		<orderItem :dishesData="orderList"></orderItem>
		<view class="orderSubmit-submit">
			<text>金额￥{{ orderData.money }}</text>
			<text @click="handleSubmit">立即提交</text>
		</view>
	</view>
</template>

<script>
import orderItem from '../../components/orderItem.vue';
import { mapState } from 'vuex';
export default {
	components: {
		orderItem
	},

	computed: {
		...mapState(['orderList','orderData'])
	},
	methods: {
		handleSubmit() {
			uni.reLaunch({
				url: '../orderDetail/index'
			});
		}
	}
};
</script>

<style lang="scss">
@import './index.scss';
</style>
