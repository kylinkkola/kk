<template>
	<view class="index">
		<view class="index-info">
			<view>欢迎光临</view>
			<view>
				<image></image>
				<view>
					<text>好吃的烧烤</text>
					<view>餐饮</view>
				</view>
			</view>
			<view>
				<image src="../../static/ic_address@2x.png"></image>
				<text>景德镇陶瓷大学</text>
			</view>
		</view>
		<view class="index-detail">
			<view>店铺详情</view>
			<image></image>
			<view>
				<view>
					<image src="../../static/ic_time@2x.png"></image>
					<text>营业时间</text>
					<text>08:00-21:00</text>
				</view>
				<view>
					<image src="../../static/ic_call@2x.png"></image>
					<text>联系电话</text>
					<text>8888-88888888</text>
				</view>
			</view>
		</view>
		<view class="index-comment">
			<view>店铺评价</view>
			<view>
				<view v-for="item in 3" :key="item">
					<text>菜肴口味</text>
					<view>
						<image v-for="item in 5" :key="item" src="../../static/ic_star@2x.png"></image>
					</view>
					<text>4.8</text>
				</view>
			</view>
			<view>
				<view v-for="item in 1" :key="item">
					<view>
						<image></image>
						<view>
							<text>kk</text>
							<view>2021-1-2 12:09</view>
						</view>
					</view>
					<view>就超好吃！强推！</view>
				</view>
			</view>
			<view>查看全部评论(37)</view>
			<view @click="handleGoOrder">
				<image src="../../static/ic_order@2x.png"></image>
				<text>去点菜</text>
			</view>
		</view>
	</view>
</template>
<script>
export default {
	data() {
		return {};
	},
	onLoad() {},
	methods: {
		handleGoOrder(){
			uni.navigateTo({
			    url: '../orderDishes/index'
			});
		}
	}
};
</script>

<style lang="scss">
@import './index.scss';
</style>
