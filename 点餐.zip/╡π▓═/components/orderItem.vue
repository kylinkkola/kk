<template>
	<view class="orderItem">
		<view>好吃的烧烤 | 7号桌</view>
		<view class="orderItem-dishes">
			<view v-for="(item, index) in dishesData" :key="index">
				<image :src="item.imgUrl"></image>
				<view>
					<text>{{ item.name }}</text>
					<view>{{ item.type }}</view>
					<view>
						<text>￥</text>
						<text>{{ item.price }}</text>
					</view>
				</view>
				<view>x {{ item.count }}</view>
				<view>
					<text>￥</text>
					<text>{{ item.price * item.count }}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
export default {
	props:{
		dishesData:""
	}
};
</script>

<style lang="scss">
.orderItem {
	& > view:nth-child(1) {
		font-size: 36rpx;
		height: 75rpx;
		line-height: 75rpx;
		padding-left: 25rpx;
		border-bottom: 1rpx dashed #ccc;
		background-color: #ffffff;
	}
}
.orderItem-dishes {
	background-color: #ffffff;
	& > view {
		display: flex;
		padding: 25rpx 25rpx 0rpx 25rpx;
		align-items: center;

		& > image {
			width: 125rpx;
			height: 125rpx;
			border-radius: 10rpx;
			background-color: red;
			margin-right: 20rpx;
		}

		& > view:nth-child(2) {
			font-size: 30rpx;

			& > view:nth-child(2) {
				font-size: 26rpx;
				color: #ccc;
				padding: 10rpx 0rpx;
			}
			& > view:nth-child(3) {
				color: red;
				text:nth-child(1) {
					font-size: 22rpx;
				}
			}
		}

		& > view:nth-child(3) {
			flex: 1;
			color: #ccc;
			text-align: right;
		}
		& > view:nth-child(4) {
			font-size: 32rpx;
			width: 140rpx;
			text-align: right;
		}
	}
}
</style>
