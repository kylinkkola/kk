<script>
export default {
	watch: {
		$route(to) {
			window.history.replaceState(null, null, window.location.href);
		}
	},
	onLaunch: function() {
		console.log('App Launch');
	},
	onShow: function() {
		console.log('App Show');
	},
	onHide: function() {
		console.log('App Hide');
	}
};
</script>

<style>
/*每个页面公共css */

html,
body {
	font-size: 26rpx;
	color: #323232;
	background-color: #f8f8f8;
}

uni-image {
	width: 100%;
	height: 100%;
}

image {
	width: 100%;
	height: 100%;
}
uni-modal {
	z-index: 9999;
}
</style>
